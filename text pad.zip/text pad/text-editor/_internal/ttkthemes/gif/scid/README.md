Installation of scid themes for Scid
====================================

Save scidthemes files in any directory.

In Scid choose:
Menu -> Options -> Theme -> Load Theme : select pkgIndex.tcl from this directory.
Menu -> Options -> Theme : select one theme of scidblue scidgreen scidmint scidpurple scidsand scidpink

Change menu color in Menu -> Options -> Setup Menu Colors... 
Suitable menu colors for the scid themes are
  Disabled          #808080  
  selectColor       #202020
  Textcolor         #202020
  Background        #d8d8d8
  select Textcolor  #f0f0f0
  select Background #5464c4  for scidblue
  select Background #7cac50  for scidmint
  select Background #50ac69  for scidgreen
  select Background #8050ac  for scidpurple
  select Background #ac9750  for scidsand
  select Background #ac5093  for scidpink
